package com.tata.cdapp;

import com.tata.cdapp.models.CD;
import org.junit.jupiter.api.*;

import java.util.Random;

import static org.junit.jupiter.api.Assertions.*;

public class CDTest {

    private CD cd1,cd2,cd3;

    @BeforeEach
    public void getInstance(){
        cd1=new CD();
        cd1.setId(new Random().nextInt(10000));
        cd1.setSinger("Singer"+new Random().nextInt(100));
        cd1.setTitle("Song"+new Random().nextInt(100));
        cd2=new CD();
        cd2.setId(new Random().nextInt(10000));
        cd2.setSinger("Singer"+new Random().nextInt(100));
        cd2.setTitle("Song"+new Random().nextInt(100));
    }

    //Id should be unique
    @Test
    @DisplayName("Test CD Id to be Unique")
    public void testIdUnique(){

        assertNotEquals(cd1.getId(),
                cd2.getId());
    }

    //Title to be unique
    @Test
    @DisplayName("Test CD Title to be Unique")
    public void testTitleUnique(){

        assertNotEquals(cd1.getTitle(),
                cd2.getTitle());
    }

    //Singer should not be null
    @Test
    @DisplayName("Test Singer should not be null")
    public void testSingerNotNull(){

        assertNotEquals("",cd1.getSinger());
    }

    //negative test case null pointer exception
    @Test()
    public void negativeTestForCDInstance(){
        assertThrows(NullPointerException.class,
                ()->{
                    cd3.getId();
                    cd3.getSinger();
                    cd3.getTitle();
                });
    }

    @RepeatedTest(20)
    void repeatedTestWithRepetitionInfo() {
        assertNotEquals(cd1.getId(),
                cd2.getId());
    }

    @AfterEach
    public void testUnReferenceInstance(){
        cd1=null;
        cd2=null;
        cd3=null;
    }
}