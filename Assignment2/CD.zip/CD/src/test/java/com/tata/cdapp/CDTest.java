package com.tata.cdapp;

import com.tata.cdapp.models.CD;
import org.junit.jupiter.api.*;

import java.util.Random;

import static org.junit.jupiter.api.Assertions.*;

public class CDTest {

    private CD cd1,cd2,cd3;

    @BeforeEach
    public void getInstance(){
        cd1=new CD();
        cd1.setId(new Random().nextInt(10000));
        cd2=new CD();
        cd2.setId(new Random().nextInt(10000));
    }

    //Id should be unique
    @Test
    @DisplayName("Test CD Id to be Unique")
    public void testIdUnique(){

        assertNotEquals(cd1.getId(),
                cd2.getId());
    }

    //negative test case null pointer exception
    @Test()
    public void negativeTestForCDInstance(){
        assertThrows(NullPointerException.class,
                ()->{
                    cd3.getId();
                });
    }

    @RepeatedTest(15)
    void repeatedTestWithRepetitionInfo() {
        assertNotEquals(cd1.getId(),
                cd2.getId());
    }

    @AfterEach
    public void testUnReferenceInstance(){
        cd1=null;
        cd2=null;
        cd3=null;
    }
}