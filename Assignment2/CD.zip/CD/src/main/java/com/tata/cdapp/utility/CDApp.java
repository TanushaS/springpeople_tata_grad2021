package com.tata.cdapp.utility;

import com.tata.cdapp.business.CDSorter;
import com.tata.cdapp.dao.CDDao;
import com.tata.cdapp.dao.CDImpl;
import com.tata.cdapp.models.CD;

import java.util.Collections;
import java.util.List;

public class CDApp {
    public static void main(String[] args){
        CDDao cdDao=new CDImpl();
        List<CD> cdList=cdDao.getAllCDs();

        //CDs before sorting....
        System.out.println("Before Sorting.....");
        for(CD cd : cdList){
            System.out.println(cd);
        }
        //sort the cd by singer name
        Collections.sort(cdList,new CDSorter());

        //CDs after sorting
        System.out.println("After Sorting.....");
        for(CD cd : cdList){
            System.out.println(cd);
        }

    }
}
