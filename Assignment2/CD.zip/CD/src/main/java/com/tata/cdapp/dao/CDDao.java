package com.tata.cdapp.dao;

import com.tata.cdapp.models.CD;

import java.util.List;

public interface CDDao {
    List<CD> getAllCDs();
}
