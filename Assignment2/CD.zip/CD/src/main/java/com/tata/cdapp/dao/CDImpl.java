package com.tata.cdapp.dao;

import com.tata.cdapp.models.CD;

import java.time.LocalDate;
import java.util.*;

public class CDImpl implements CDDao{
    @Override
    public List<CD> getAllCDs() {
        return getData();
    }

    private List<CD> getData(){
        List<CD> cdList=new ArrayList<CD>();
        CD cd=null;
        String[] s= new String[]{"Ram", "Sita", "Sham", "John", "Jack"};
        for(int i=0;i<5;i++){

            cd=new CD();
            cd.setId(new Random().nextInt(10000));
            cd.setTitle("Title"+i);
            cd.setSinger(s[i]);
            cdList.add(cd);
        }

        return cdList;
    }
}
