package com.shoppersden.utility;

import com.shoppersden.dao.AdminDao;
import com.shoppersden.dao.AdminImpl;
import com.shoppersden.dao.ProductDao;
import com.shoppersden.dao.ProductImpl;

import java.sql.SQLException;
import java.util.Scanner;

public class ShoppersDenApp {
    private static Scanner scanner;

    public static void main(String[] args) throws SQLException {
        scanner=new Scanner(System.in);
        int choice;
        System.out.println("Welcome to Shoppers Den...!");
        System.out.println("1.Customer\n2.Admin");
        choice=scanner.nextInt();
        switch (choice){
            case 1:
                CustomerApp customerApp=new CustomerApp();
                customerApp.CustomerApplication();
                break;
            case 2:
                AdminApp adminApp=new AdminApp();
                adminApp.AdminApplication();
                break;
            default:
                System.out.println("Invalid choice");
                break;
        }
    }
}
