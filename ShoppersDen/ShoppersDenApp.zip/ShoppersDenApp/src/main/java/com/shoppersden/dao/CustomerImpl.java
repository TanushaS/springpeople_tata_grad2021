package com.shoppersden.dao;

import com.shoppersden.models.*;
import com.shoppersden.helpers.PostgresConnHelper;

import java.util.*;

import java.sql.*;

public class CustomerImpl implements CustomerDao {
    private Connection conn;
    private Cart cart;
    private boolean flag = false;
    private PreparedStatement loginPrepStatement;
    private PreparedStatement registerPrepStatement;
    private PreparedStatement addressPrepStatement;
    private PreparedStatement getAddressPrepStatement;
    private ResourceBundle resourceBundle;
    private CartDao cartDao = new CartImpl();

    public CustomerImpl() throws SQLException {
        conn = PostgresConnHelper.getConnection();
        conn.setAutoCommit(false);
        resourceBundle = ResourceBundle.getBundle("db");
        if (conn != null)
            System.out.println("Connection Established...");
        else
            System.out.println("Connection Failed...");
    }

    @Override
    public void addProductToCart(Product product, int qty) {
        if (cart == null) {
            System.out.println("Please Login !");
            return;
        }
        cartDao.addToCart(cart, product, qty);
    }

    @Override
    public void removeProductFromCart(String pname) {
        if (cart == null) {
            System.out.println("Please Login !");
            return;
        }
        cartDao.removeFromCart(cart, pname);
    }

    @Override
    public void viewTransaction(int cid) throws SQLException{
        TransactionDao transactionDao=new TransactionImpl();
        transactionDao.viewTransaction(cid);
    }

    @Override
    public boolean login(int uid, String pwd) {
        String loginQuery = resourceBundle.getString("loginQuery");
        flag = false;
        try {
            loginPrepStatement = conn.prepareStatement(loginQuery);
            loginPrepStatement.setInt(1, uid);
            ResultSet resultSet = loginPrepStatement.executeQuery();

            while (resultSet.next()) {
                if (resultSet.getString("password").equals(pwd)) {
                    flag = true;
                    System.out.println("Welcome " + resultSet.getString("name"));
                }
            }
        } catch (SQLException throwables) {
            throwables.printStackTrace();
        }
        if (flag) {
            cart = new Cart();
            cart.setCartId(uid);
            cart.setProductList(new ArrayList<Product>());
        }
        else {
            System.out.println("Invalid credentials");
        }
        return flag;
    }

    @Override
    public void register(Customer customer) {
        String registerQuery = resourceBundle.getString("createCustomer");
        try {
            registerPrepStatement = conn.prepareStatement(registerQuery);
            registerPrepStatement.setInt(1,customer.getUid());
            registerPrepStatement.setString(2, customer.getName());
            registerPrepStatement.setLong(3, customer.getPhoneNumber());
            registerPrepStatement.setString(4, customer.getEmail());
            registerPrepStatement.setString(5,customer.getAddress());
            registerPrepStatement.setString(6, customer.getPwd());
            registerPrepStatement.setString(7, customer.getSecret_quest());
            registerPrepStatement.setString(8, customer.getSecret_ans());
            registerPrepStatement.executeUpdate();
            conn.commit();
            System.out.println("Successfully Registered");
        } catch (SQLException throwables) {
            throwables.printStackTrace();
        }
    }

    @Override
    public void updateCart(String pname, int qty) {
        if (!flag || cart == null) {
            System.out.println("Please Login...!");
            return;
        }
        cartDao.updateCart(cart, pname, qty);
    }

    @Override
    public void viewCart() {
        cartDao.displayCart(cart);
    }

    @Override
    public void makePayment(int uid) throws SQLException {
        if (!flag) {
            System.out.println("Please Login...!");
            return;
        }
        TransactionDao transactionDao=new TransactionImpl();
        transactionDao.addTransaction(cart,uid);

    }

    @Override
    public void search(String cname) throws SQLException {

        ProductDao productDao=new ProductImpl();
        productDao.displayProducts(cname);
    }
}