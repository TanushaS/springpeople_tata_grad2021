package com.shoppersden.dao;

import com.shoppersden.models.Cart;
import com.shoppersden.models.Product;

public interface CartDao {
    void addToCart(Cart cart, Product product,int quantity);
    void removeFromCart(Cart cart,String pname);
    void updateCart(Cart cart,String pname,int quantity);
    void displayCart(Cart cart);
}
