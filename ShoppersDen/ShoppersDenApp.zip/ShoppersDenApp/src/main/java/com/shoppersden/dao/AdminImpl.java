package com.shoppersden.dao;

import com.shoppersden.helpers.PostgresConnHelper;
import com.shoppersden.models.Category;
import com.shoppersden.models.Product;
import com.shoppersden.models.Transaction;

import java.sql.*;
import java.time.LocalDate;
import java.util.List;
import java.util.ResourceBundle;

public class AdminImpl implements AdminDao{
    private Connection conn;
    private PreparedStatement addPrepStatement;
    private PreparedStatement accountPrepStatement;
    private PreparedStatement addCategoryPrepStatement;
    private PreparedStatement adminLoginPrepStatement;
    private PreparedStatement deleteProductPrepStatement;
    private PreparedStatement updateProductPrepStatement;
    private PreparedStatement allTransactionsStatement;
    private PreparedStatement updateCategoryPrepStatement;
    private PreparedStatement deleteCategoryPrepStatement;
    private ResourceBundle resourceBundle;
    private long admin_id = 0;
    public AdminImpl() throws SQLException {
        conn = PostgresConnHelper.getConnection();
        conn.setAutoCommit(false);
        resourceBundle = ResourceBundle.getBundle("db");
        if (conn != null)
            System.out.println("Connection Established...");
        else
            System.out.println("Connection Failed...");
    }
    @Override
    public void addProductToCategory(Product product) throws SQLException {
        String insertProduct = resourceBundle.getString("addProduct");
        try {
            addPrepStatement = conn.prepareStatement(insertProduct);
            addPrepStatement.setInt(1,product.getPid());
            addPrepStatement.setString(2,product.getPName());
            addPrepStatement.setDate(3, Date.valueOf(product.getDate()));
            addPrepStatement.setDouble(4,product.getPrice());
            addPrepStatement.setInt(5,product.getQuantity());
            addPrepStatement.setLong(6,product.getCategoryId());
            addPrepStatement.executeUpdate();
            System.out.println("Product Inserted");
        }catch (SQLException s){
            s.printStackTrace();
        }
        conn.commit();
    }

    @Override
    public void deleteProductFromCategory(int productId) {
        String deleteProductQuery = resourceBundle.getString("deleteProduct");
        try{
            deleteProductPrepStatement = conn.prepareStatement(deleteProductQuery);
            deleteProductPrepStatement.setInt(1,productId);
            deleteProductPrepStatement.executeUpdate();
            conn.commit();
            System.out.println("Product Deleted");
        } catch (SQLException throwables) {
            throwables.printStackTrace();
        }
    }

    @Override
    public void updateProductInCategory(int productId,float price,int quantity) {
        String updateProductQuery = resourceBundle.getString("updateProduct");
        try{
            updateProductPrepStatement = conn.prepareStatement(updateProductQuery);
            updateProductPrepStatement.setFloat(1,price);
            updateProductPrepStatement.setInt(2,quantity);
            updateProductPrepStatement.setInt(3,productId);
            updateProductPrepStatement.executeUpdate();
            conn.commit();
            System.out.println("Product Updated");
        } catch (SQLException throwables) {
            throwables.printStackTrace();
        }

    }

    @Override
    public void addCategory(String CategoryName) {
        String addCategoryQuery = resourceBundle.getString("addCategory");
        try{
            addCategoryPrepStatement = conn.prepareStatement(addCategoryQuery);
            addCategoryPrepStatement.setString(1,CategoryName);
            addCategoryPrepStatement.executeUpdate();
            conn.commit();
            System.out.println("Category Inserted");
        } catch (SQLException throwables) {
            throwables.printStackTrace();
        }
    }

    @Override
    public void updateCategory(int cid,String cname) {
        String deleteProductQuery = resourceBundle.getString("updateCategory");
        try{
            updateCategoryPrepStatement = conn.prepareStatement(deleteProductQuery);
            updateCategoryPrepStatement.setString(1,cname);
            updateCategoryPrepStatement.setInt(2,cid);
            updateCategoryPrepStatement.executeUpdate();
            conn.commit();
            System.out.println("Category Updated");
        } catch (SQLException throwables) {
            throwables.printStackTrace();
        }

    }

    @Override
    public void deleteCategory(int cid) {
        String deleteCategoryQuery = resourceBundle.getString("deleteCategory");
        try{
            deleteCategoryPrepStatement = conn.prepareStatement(deleteCategoryQuery);
            deleteCategoryPrepStatement.setInt(1,cid);
            deleteCategoryPrepStatement.executeUpdate();
            conn.commit();
            System.out.println("Category Deleted");
        } catch (SQLException throwables) {
            throwables.printStackTrace();
        }

    }

    @Override
    public boolean login(int aid, String pwd) {
        String adminLoginQuery = resourceBundle.getString("adminLogin");
        boolean loginFlag=false;
        try{
            adminLoginPrepStatement = conn.prepareStatement(adminLoginQuery);
            adminLoginPrepStatement.setInt(1,aid);
            adminLoginPrepStatement.setString(2,pwd);
            ResultSet resultSet = adminLoginPrepStatement.executeQuery();
            while (resultSet.next()){
                if (resultSet.getString("password").equals(pwd)) {
                    loginFlag = true;
                    System.out.println("Welcome " + resultSet.getString("Name"));
                }
                else {
                    System.out.println("Invalid Credentials");
                    return false;
                }
            }
        } catch (SQLException throwables) {
            throwables.printStackTrace();
        }
        return loginFlag;
    }

    @Override
    public void viewTransactions() throws SQLException {
        String allTransactionsQuery=resourceBundle.getString("getAllTransaction");
        try{
            allTransactionsStatement = conn.prepareStatement(allTransactionsQuery);
            ResultSet res = allTransactionsStatement.executeQuery();
            System.out.println("Product Name \t Qty Purchased \t Cost \t Date Of Purchase\tCustomer Id");
            System.out.println("========================================================================================");
            while (res.next()){
                System.out.println(res.getString("product_name") + " \t\t "
                        + res.getInt("quantity") + " \t\t "
                        + res.getFloat("amount") + " \t\t "
                        + res.getDate("dop")+"\t\t"
                        + res.getInt("customer_id"));
            }
        } catch (SQLException throwables) {
            throwables.printStackTrace();
        }
    }
}