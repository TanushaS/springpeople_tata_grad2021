package com.shoppersden.dao;

import com.shoppersden.models.Transaction;
import com.shoppersden.models.Cart;
import com.shoppersden.models.Customer;
import java.util.List;

public interface TransactionDao {
    List<Transaction> getAllTransactions();
    void viewTransaction(int cid);
    void addTransaction(Cart cart,int uid);
}
