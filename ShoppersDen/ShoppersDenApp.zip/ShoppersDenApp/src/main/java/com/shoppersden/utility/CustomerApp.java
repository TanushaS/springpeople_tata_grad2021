package com.shoppersden.utility;

import com.shoppersden.dao.CustomerDao;
import com.shoppersden.dao.CustomerImpl;
import com.shoppersden.models.Cart;
import com.shoppersden.models.CreditCard;
import com.shoppersden.models.Customer;
import com.shoppersden.models.Product;

import java.sql.SQLException;
import java.util.Scanner;

public class CustomerApp {
    int choice,cid,qty,cvv;
    Product product;
    String pwd,name,email,addr,secretq,secreta,cname,cardName,date,pname;
    long phoneNo,cardNo;
    float price;
    boolean status;
    Cart cart;
    CreditCard creditCard;
    Customer customer;

    public void CustomerApplication() throws SQLException {
        Scanner scanner=new Scanner(System.in);
        CustomerDao customerDao=new CustomerImpl();
        while (true) {
            System.out.println("---------------------------------------------");
            System.out.println("Menu");
            System.out.println("---------------------------------------------");
            System.out.println("1.Register\n" +
                    "2.Login\n" +
                    "3.Add Product to Cart\n" +
                    "4.Remove product from Cart\n" +
                    "5.Update Cart\n" +
                    "6.View Cart\n"+
                    "7.Search\n" +
                    "8.View Transactions\n"+
                    "9.Make Payment\n"+
                    "10.Exit");
            System.out.println("---------------------------------------------");
            choice=scanner.nextInt();
            switch (choice){
                case 1:
                    System.out.println("---------------------------------------------");
                    System.out.println("Registration Form");
                    System.out.println("---------------------------------------------");
                    System.out.println("Enter User Id");
                    cid=scanner.nextInt();
                    System.out.println("Enter User Name");
                    name=scanner.next();
                    System.out.println("Enter User Phone Number");
                    phoneNo=scanner.nextLong();
                    System.out.println("Enter User Email");
                    email=scanner.next();
                    System.out.println("Enter User Address");
                    addr=scanner.next();
                    System.out.println("Enter User password");
                    pwd=scanner.next();
                    System.out.println("Enter Secret Question");
                    secretq=scanner.next();
                    System.out.println("Enter Secret Answer");
                    secreta=scanner.next();
                    cart=new Cart();
                    cart.setCartId(cid);
                    customer=new Customer(cid,name,phoneNo,email,addr,pwd,secretq,secreta,cart);
                    customerDao.register(customer);
                    break;
                case 2:System.out.println("---------------------------------------------");
                    System.out.println("Login Form");
                    System.out.println("---------------------------------------------");
                    System.out.println("Enter User Id:");
                    cid=scanner.nextInt();
                    System.out.println("Enter password");
                    pwd=scanner.next();
                    status=customerDao.login(cid,pwd);
                    break;
                case 3:
                    System.out.println("Enter product Name");
                    pname = scanner.next();
                    System.out.println("Enter product price");
                    price = scanner.nextFloat();
                    System.out.println("Enter product quantity");
                    qty = scanner.nextInt();
                    product=new Product();
                    product.setQuantity(qty);
                    product.setPName(pname);
                    product.setPrice(price);
                    customerDao.addProductToCart(product,qty);
                    break;
                case 4:
                    System.out.println("Enter Product Name");
                    pname=scanner.next();
                    customerDao.removeProductFromCart(pname);
                    break;
                case 5:
                    System.out.println("Enter Product Name");
                    pname=scanner.next();
                    System.out.println("Enter product quantity");
                    qty = scanner.nextInt();
                    customerDao.updateCart(pname,qty);
                    break;
                case 6:
                    System.out.println("Shopping Cart");
                    customerDao.viewCart();
                    break;
                case 7:
                    System.out.println("Enter Category Name");
                    cname=scanner.next();
                    customerDao.search(cname);
                    break;
                case 8:
                    System.out.println("Enter User Id");
                    cid=scanner.nextInt();
                    System.out.println("Your Transactions Details");
                    customerDao.viewTransaction(cid);
                    break;
                case 9:
                    System.out.println("Enter Credit Card Details");
                    System.out.println("Enter Card Number");
                    cardNo=scanner.nextLong();
                    System.out.println("Enter Name on Card");
                    cardName=scanner.next();
                    System.out.println("Enter Card Validity");
                    date=scanner.next();
                    System.out.println("Enter CVV");
                    cvv=scanner.nextInt();
                    creditCard=new CreditCard(cid,cvv,date,cardName,cardNo);
                    customerDao.makePayment(cid);
                    break;
                case 10:
                    System.out.println("Thank You...!");
                    return;
                default:
                    System.out.println("Invalid choice");
                    break;
            }
        }

    }
}
