package com.shoppersden.models;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.time.LocalDate;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class Product {
    private int pid;
    private String pName;
    private LocalDate date;
    private float price;
    private int quantity;
    private int categoryId;

}
