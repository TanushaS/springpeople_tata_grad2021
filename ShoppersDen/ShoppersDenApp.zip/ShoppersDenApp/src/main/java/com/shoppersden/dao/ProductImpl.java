package com.shoppersden.dao;

import com.shoppersden.helpers.PostgresConnHelper;
import com.shoppersden.models.Product;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;
import java.util.ResourceBundle;


public class ProductImpl implements ProductDao{
    private Connection conn;
    private Statement statement;
    private PreparedStatement preparedStatement;
    private ResourceBundle resourceBundle;
    public ProductImpl() throws SQLException {
        conn = PostgresConnHelper.getConnection();
        conn.setAutoCommit(false);
        resourceBundle = ResourceBundle.getBundle("db");
        if (conn != null)
            System.out.println("Connection Established...");
        else
            System.out.println("Connection Failed...");
    }
    @Override
    public void displayProducts(String cname) {
        String displayProducts = resourceBundle.getString("displayProducts");
        try {
            preparedStatement=conn.prepareStatement(displayProducts);
            preparedStatement.setString(1,cname);
            ResultSet resultSet = preparedStatement.executeQuery();
            System.out.println("Sl No\tProduct Id\tProduct Name\tDate Of Manufacture\tPrice");
            System.out.println("========================================================================================");
            int i= 0;
            while (resultSet.next()){
                i++;
                System.out.println(i + "\t\t" + resultSet.getInt("product_id")
                        + "\t\t" + resultSet.getString("product_name")  +"\t\t"
                        + resultSet.getDate("dom") + "\t\t"
                        + resultSet.getFloat("price"));
            }
        } catch (SQLException throwables) {
            throwables.printStackTrace();
        }
    }

    @Override
    public List<Product> getAllProducts() {
        List<Product> productList = new ArrayList<Product>(10);
        String displayProducts = resourceBundle.getString("displayProducts");
        try (Statement statement = conn.createStatement()) {
            ResultSet resultSet = statement.executeQuery(displayProducts);
            Product product;
            while (resultSet.next()){
                product = new Product();
                product.setPid(resultSet.getInt("prod_id"));
                product.setCategoryId(resultSet.getInt("category_id"));
                product.setDate(resultSet.getDate("date").toLocalDate());
                product.setPrice(resultSet.getFloat("price"));
                product.setPName(resultSet.getString("prod_name"));
                productList.add(product);
            }
        } catch (SQLException throwables) {
            throwables.printStackTrace();
        }
        return productList;
    }
}

