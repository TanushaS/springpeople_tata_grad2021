package com.shoppersden.dao;

import com.shoppersden.models.Product;
import java.util.List;

public interface ProductDao {
    void displayProducts(String cname);
    List<Product> getAllProducts();
}
