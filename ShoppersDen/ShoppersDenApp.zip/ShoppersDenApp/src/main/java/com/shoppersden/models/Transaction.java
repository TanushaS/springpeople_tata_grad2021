package com.shoppersden.models;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.time.LocalDate;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class Transaction {
    private int tid;
    private int pid;
    private int quantity;
    private int customerId;
    private String pName;
    private LocalDate date;
    private float amount;
}
