package com.shoppersden.dao;

import com.shoppersden.helpers.PostgresConnHelper;
import com.shoppersden.models.Cart;
import com.shoppersden.models.Customer;
import com.shoppersden.models.Product;
import com.shoppersden.models.Transaction;

import java.sql.*;
import java.sql.Date;
import java.time.LocalDate;
import java.util.*;

public class TransactionImpl implements TransactionDao{
    private Connection conn;
    private ResourceBundle resourceBundle;
    private PreparedStatement transactionPrepStatement;
    private PreparedStatement transactionAddPrepStatement;
    private PreparedStatement allTransactionsStatement;

    public TransactionImpl() throws SQLException {
        conn = PostgresConnHelper.getConnection();
        conn.setAutoCommit(false);
        resourceBundle = ResourceBundle.getBundle("db");
        if (conn != null)
            System.out.println("Connection Established...");
        else
            System.out.println("Connection Failed...");

    }

    @Override
    public void viewTransaction(int cid) {
        String transactionQuery = resourceBundle.getString("viewTransaction");
        try{
            transactionPrepStatement = conn.prepareStatement(transactionQuery);
            transactionPrepStatement.setInt(1,cid);
            ResultSet resultSet = transactionPrepStatement.executeQuery();
            System.out.println("Product Name \t Qty Purchased \t Cost \t Date Of Purchase");
            System.out.println("========================================================================================");
            while (resultSet.next()){
                System.out.println( resultSet.getString("product_name")
                        + " \t\t " + resultSet.getInt("quantity")
                        + " \t\t " + resultSet.getDouble("amount")
                        + " \t\t " + resultSet.getDate("dop"));
            }
        } catch (SQLException throwables) {
            throwables.printStackTrace();
        }
    }

    @Override
    public void addTransaction(Cart cart,int uid) {
        String transactionAddQuery = resourceBundle.getString("addTransaction");
        List<Product> productList = cart.getProductList();
        try{
            transactionAddPrepStatement = conn.prepareStatement(transactionAddQuery);
            for (Product p:productList) {
                transactionAddPrepStatement.setInt(1,p.getPid());
                transactionAddPrepStatement.setLong(2,p.getQuantity());
                transactionAddPrepStatement.setLong(3,uid);
                transactionAddPrepStatement.setString(4,p.getPName());
                transactionAddPrepStatement.setDate(5,Date.valueOf(LocalDate.now()));
                transactionAddPrepStatement.setFloat(6,(p.getPrice() * p.getQuantity()));
                transactionAddPrepStatement.executeUpdate();
            }
            conn.commit();
        } catch (SQLException throwables) {
            throwables.printStackTrace();
        }
    }

    @Override
    public List<Transaction> getAllTransactions() {
        String allTransactionsQuery = resourceBundle.getString("getAllTransaction");
        List<Transaction> transactionList = new ArrayList<Transaction>(10);
        Transaction transaction;
        try{
            allTransactionsStatement = conn.prepareStatement(allTransactionsQuery);
            ResultSet resultSet = allTransactionsStatement.executeQuery();
            while (resultSet.next()){
                transaction = new Transaction();
                transaction.setPid(resultSet.getInt("product_id"));
                transaction.setPName(resultSet.getString("product_name"));
                transaction.setQuantity(resultSet.getInt("quantity"));
                transaction.setAmount(resultSet.getFloat("amount"));
                transaction.setDate(resultSet.getDate("dop").toLocalDate());
                transaction.setCustomerId(resultSet.getInt("customer_id"));
                transaction.setTid(resultSet.getInt("transaction_id"));
                transactionList.add(transaction);
            }
        } catch (SQLException throwables) {
            throwables.printStackTrace();
        }
        return transactionList;
    }
}
