package com.shoppersden.dao;

import com.shoppersden.models.Cart;
import com.shoppersden.models.Product;
import java.util.List;

public class CartImpl implements CartDao{
    @Override
    public void addToCart(Cart cart, Product product, int quantity) {
        List<Product> productList= cart.getProductList();
        product.setQuantity(quantity);
        productList.add(product);
    }

    @Override
    public void removeFromCart(Cart cart, String pname) {
        List<Product> productList= cart.getProductList();
        for(Product p:productList)
        {
            if(p.getPName().equals(pname)) {
                productList.remove(p);
                break;
            }
        }

    }

    @Override
    public void updateCart(Cart cart, String pname, int quantity) {
        List<Product> productList= cart.getProductList();
        for(Product p:productList){
            if(p.getPName().equals(pname)){
                p.setQuantity(quantity);
                break;
            }
        }

    }

    @Override
    public void displayCart(Cart cart) {
        System.out.println("Product Name \t Quantity \t Price");
        List<Product> productList=cart.getProductList();
        for (Product product:productList){
            System.out.println(product.getPName()+"\t\t"
                    +product.getQuantity()+"\t\t"
                    +product.getPrice());
        }
    }
}
