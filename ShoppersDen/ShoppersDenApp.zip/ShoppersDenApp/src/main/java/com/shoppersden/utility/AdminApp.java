package com.shoppersden.utility;

import com.shoppersden.dao.AdminDao;
import com.shoppersden.dao.AdminImpl;
import com.shoppersden.models.Product;

import java.sql.SQLException;
import java.time.LocalDate;
import java.util.Scanner;

public class AdminApp {
    boolean status;
    int choice;
    int cid,pid,qty;
    float price;
    LocalDate dom;
    String cn,pn;
    Product product;

    public void AdminApplication() throws SQLException {
        Scanner scanner=new Scanner(System.in);
        AdminDao adminDao=new AdminImpl();
        System.out.println("Login Form");
        System.out.println("Enter Admin Id:");
        int aid=scanner.nextInt();
        System.out.println("Enter password");
        String pwd=scanner.next();
        status=adminDao.login(aid,pwd);
        if(status) {
            while (true) {
                System.out.println("---------------------------------------------");
                System.out.println("Menu:");
                System.out.println("---------------------------------------------");
                System.out.println("1.Add Product to Category\n" +
                        "2.Delete Product from Category\n" +
                        "3.Update Product in Category\n" +
                        "4.Add Category\n" +
                        "5.Delete Category\n" +
                        "6.Update Category\n" +
                        "7.View Transactions\n" +
                        "8.Logout");
                System.out.println("---------------------------------------------");
                choice = scanner.nextInt();
                switch (choice) {
                    case 1:
                        System.out.println("Enter product id");
                        pid = scanner.nextInt();
                        System.out.println("Enter product name");
                        pn = scanner.next();
                        System.out.println("Enter product price");
                        price = scanner.nextFloat();
                        System.out.println("Enter product quantity");
                        qty = scanner.nextInt();
                        System.out.println("Enter category Id");
                        cid = scanner.nextInt();
                        product = new Product(pid, pn, LocalDate.now(), price, qty, cid);
                        adminDao.addProductToCategory(product);
                        break;
                    case 2:
                        System.out.println("Enter product id");
                        pid = scanner.nextInt();
                        adminDao.deleteProductFromCategory(pid);
                        break;
                    case 3:
                        System.out.println("Enter product id");
                        pid = scanner.nextInt();
                        System.out.println("Enter price");
                        price = scanner.nextFloat();
                        System.out.println("Enter Quantity");
                        qty = scanner.nextInt();
                        adminDao.updateProductInCategory(pid, price, qty);
                        break;
                    case 4:
                        System.out.println("Enter category name");
                        cn = scanner.next();
                        adminDao.addCategory(cn);
                        break;
                    case 5:
                        System.out.println("Enter category Id");
                        cid = scanner.nextInt();
                        adminDao.deleteCategory(cid);
                        break;
                    case 6:
                        System.out.println("Enter category Id");
                        cid = scanner.nextInt();
                        System.out.println("Enter category name");
                        cn = scanner.next();
                        adminDao.updateCategory(cid, cn);
                        break;
                    case 7:
                        adminDao.viewTransactions();
                        break;
                    case 8:
                        System.out.println("Thank you!");
                        return;
                    default:
                        System.out.println("Invalid choice");
                        break;
                }

            }
        }
        else{
            System.out.println("Please enter valid Details...");
            AdminApplication();
        }
    }

}
