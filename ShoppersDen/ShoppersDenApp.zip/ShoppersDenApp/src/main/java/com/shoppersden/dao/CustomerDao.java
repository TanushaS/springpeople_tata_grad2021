package com.shoppersden.dao;

import com.shoppersden.models.Category;
import com.shoppersden.models.Customer;
import com.shoppersden.models.Product;

import java.sql.SQLException;
import java.util.List;

public interface CustomerDao {
    void addProductToCart(Product product,int quantity);
    void removeProductFromCart(String pname);
    void updateCart(String pname,int quantity);
    void viewCart();
    boolean login(int uid,String uPwd);
    void register(Customer customer);
    void makePayment(int uid) throws SQLException;
    void search(String cname) throws SQLException;
    void viewTransaction(int cid) throws SQLException;
}
