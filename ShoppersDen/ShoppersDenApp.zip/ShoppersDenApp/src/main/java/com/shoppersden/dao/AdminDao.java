package com.shoppersden.dao;

import com.shoppersden.models.Category;
import com.shoppersden.models.Product;

import java.sql.SQLException;

public interface AdminDao {
    void addProductToCategory(Product product) throws SQLException;
    void deleteProductFromCategory(int productId);
    void updateProductInCategory(int productId,float price,int quantity);
    void addCategory(String  categoryName);
    void updateCategory(int categoryId,String cname);
    void deleteCategory(int cid);
    boolean login(int aid,String aPwd);
    void viewTransactions() throws SQLException;

}
