package com.tata.workerapp.utility;

import com.tata.workerapp.models.DailyWorker;
import com.tata.workerapp.models.SalariedWorker;
import com.tata.workerapp.models.Worker;

import java.util.Random;

public class WorkersApp {
    public static void main(String[] args){

        //Daily Worker
        Worker dailyWorker = new DailyWorker();
        dailyWorker.setName("Ram");
        dailyWorker.setSalaryRate((new Random().nextFloat())*(new Random().nextInt(100)));
        System.out.println("Daily Worker Details");
        printDetails(dailyWorker);

        //Salaried Worker
        Worker salariedWorker = new SalariedWorker();
        salariedWorker.setName("Sham");
        salariedWorker.setSalaryRate((new Random().nextFloat())*(new Random().nextInt(100)));
        System.out.println("Salaried Worker Details");
        printDetails(salariedWorker);
    }

    public static void printDetails(Worker worker){
        System.out.println("Name: "+worker.getName());
        System.out.println("Salary Rate: "+worker.getSalaryRate());
        System.out.println("Week Pay of the Worker:"+worker.Pay(new Random().nextInt(50)));

    }

}
