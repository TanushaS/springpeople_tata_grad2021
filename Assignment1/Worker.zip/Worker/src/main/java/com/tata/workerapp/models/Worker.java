package com.tata.workerapp.models;

import lombok.Data;

@Data
public abstract class Worker {
    protected String name;
    protected float salaryRate;

    public abstract float Pay(int hours);
}
