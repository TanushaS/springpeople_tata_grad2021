package com.tata.workerapp.models;

import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@EqualsAndHashCode(callSuper = false)
public class DailyWorker extends Worker {

    @Override
    public float Pay(int hours) {
        return hours*salaryRate;
    }
}
