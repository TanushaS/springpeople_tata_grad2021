package com.tata.workerapp.models;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.EqualsAndHashCode;

@Data
@AllArgsConstructor
@EqualsAndHashCode(callSuper = false)
public class SalariedWorker extends Worker{
    @Override
    public float Pay(int hours) {
        return 40*salaryRate;
    }
}
