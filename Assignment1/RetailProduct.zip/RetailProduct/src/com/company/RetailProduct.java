package com.company;
import java.util.Scanner;

public class RetailProduct {

    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);

        float totalRetailPrice = 0;
        int choice;
        int quantity;

        System.out.println("1 : Product 1 - Rs 22.50");

        System.out.println("2 : Product 2 - Rs 44.50");

        System.out.println("3 : Product 3 - Rs 9.98");

        System.out.println("4 : Exit program");

        while (true) {

            System.out.print("Enter the product number: ");

            choice = sc.nextInt();
            quantity=-1;
            if(choice==4){
                System.out.println("Thank you!");
                break;
            }

            if(choice !=3 && choice !=2 && choice !=1){
                System.out.println("Enter valid product number");
                continue;
            }

            while (quantity<0) {
                System.out.print("Enter quantity sold: ");
                quantity = sc.nextInt();
            }
            switch (choice) {

                case 1:
                    totalRetailPrice += 22.50 * quantity;
                    break;

                case 2:
                    totalRetailPrice += 44.50 * quantity;
                    break;

                case 3:
                    totalRetailPrice += 9.98 * quantity;
                    break;

                default:
                    totalRetailPrice += 0;
                    break;
            }

            System.out.println("The retail value of selected products: " + totalRetailPrice);
        }

        System.out.println("The Total Retail value of the Products sold: " + totalRetailPrice);

    }
}
